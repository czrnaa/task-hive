-- 1. Create database
CREATE DATABASE IF NOT EXISTS task_hive_db;
USE task_hive_db;

-- 2. Create users table (with email verification support)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    token VARCHAR(255) DEFAULT NULL, -- for token column for email verification
    is_verified TINYINT(1) DEFAULT 0,   -- for is_verified flag to track email verification
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Create jobs table
CREATE TABLE IF NOT EXISTS jobs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    payment_mode VARCHAR(50),
    work_setup VARCHAR(50),
    deadline DATE,
    image_path VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);