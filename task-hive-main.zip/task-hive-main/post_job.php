<?php
include("includes/session.php");
include("database/config.php");

// Ensure user is logged in
ensureLoggedIn();

$message = "";
$error = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $payment_mode = $_POST['payment_mode'];
    $work_setup = $_POST['work_setup'];
    $deadline = $_POST['deadline'];
    $user_id = $_SESSION['user_id'];
    
    // Validate required fields
    if (empty($title) || empty($description) || empty($payment_mode) || empty($work_setup) || empty($deadline)) {
        $error = "All fields are required.";
    } else {
        $image_path = "";
        
                // Handle image upload
        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
            $max_size = 5 * 1024 * 1024; // 5MB
            
            if (in_array($_FILES['image']['type'], $allowed_types) && $_FILES['image']['size'] <= $max_size) {
                $upload_dir = "assets/images/";
                
                // Create directory if it doesn't exist
                if (!file_exists($upload_dir)) {
                    mkdir($upload_dir, 0777, true);
                }
                
                // Store temporary file path for later renaming
                $temp_upload_path = $upload_dir . uniqid() . '.' . pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
                
                if (move_uploaded_file($_FILES['image']['tmp_name'], $temp_upload_path)) {
                    $temp_image_path = $temp_upload_path;
                } else {
                    $error = "Failed to upload image. Please try again.";
                }
            } else {
                $error = "Invalid image format or size. Please upload a valid image (JPEG, PNG, GIF) under 5MB.";
            }
        }
        
        // If no errors, insert into database
        if (empty($error)) {
            $stmt = $conn->prepare("INSERT INTO jobs (user_id, title, description, payment_mode, work_setup, deadline, image_path, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
            $stmt->bind_param("issssss", $user_id, $title, $description, $payment_mode, $work_setup, $deadline, $temp_image_path);
            
            if ($stmt->execute()) {
                $job_id = $conn->insert_id; // Get the auto-generated job ID
                
                // Rename the image file to include the job ID
                if (isset($temp_image_path) && file_exists($temp_image_path)) {
                    $file_extension = pathinfo($temp_image_path, PATHINFO_EXTENSION);
                    $new_file_name = "imgid" . $job_id . "." . $file_extension;
                    $new_upload_path = $upload_dir . $new_file_name;

                    if (rename($temp_image_path, $new_upload_path)) {
                        // Save only the filename to the database
                        $relative_image_path = $new_file_name;

                        $update_stmt = $conn->prepare("UPDATE jobs SET image_path = ? WHERE id = ?");
                        $update_stmt->bind_param("si", $relative_image_path, $job_id);
                        $update_stmt->execute();
                        $update_stmt->close();
                    }
                }

                
                $message = "Job posted successfully!";
                // Clear form data
                $_POST = array();
            } else {
                $error = "Error posting job: " . $conn->error;
            }
            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task Hive | Post a Job</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <div class="page-header">
            <h1>Post a New Job</h1>
            <p>Share your project and find the perfect freelancer for your needs</p>
        </div>
        
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="account.php">Account</a></li>
                <li><a href="browse_job.php">Browse Jobs</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>

        <?php if (!empty($message)): ?>
            <div class="alert alert-success">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($error)): ?>
            <div class="alert alert-error">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <div class="form-container">
            <form method="POST" enctype="multipart/form-data">
                <div class="form-section">
                    <h3>Basic Information</h3>
                    <div class="form-group">
                        <label for="title">Job Title <span class="required">*</span></label>
                        <input type="text" id="title" name="title" value="<?php echo isset($_POST['title']) ? htmlspecialchars($_POST['title']) : ''; ?>" placeholder="e.g., Web Developer Needed for E-commerce Site" required>
                        <div class="help-text">Be specific and descriptive to attract the right candidates</div>
                    </div>

                    <div class="form-group">
                        <label for="description">Job Description <span class="required">*</span></label>
                        <textarea id="description" name="description" placeholder="Describe the project requirements, skills needed, and what you're looking for..." required><?php echo isset($_POST['description']) ? htmlspecialchars($_POST['description']) : ''; ?></textarea>
                        <div class="help-text">Include project scope, required skills, deliverables, and any specific requirements</div>
                    </div>
                </div>

                <div class="form-section">
                    <h3>Job Details</h3>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="payment_mode">Payment Mode <span class="required">*</span></label>
                            <select id="payment_mode" name="payment_mode" required>
                                <option value="">Select payment mode</option>
                                <option value="Hourly" <?php echo (isset($_POST['payment_mode']) && $_POST['payment_mode'] == 'Hourly') ? 'selected' : ''; ?>>Hourly Rate</option>
                                <option value="Fixed" <?php echo (isset($_POST['payment_mode']) && $_POST['payment_mode'] == 'Fixed') ? 'selected' : ''; ?>>Fixed Price</option>
                                <option value="Per Project" <?php echo (isset($_POST['payment_mode']) && $_POST['payment_mode'] == 'Per Project') ? 'selected' : ''; ?>>Per Project</option>
                                <option value="Commission" <?php echo (isset($_POST['payment_mode']) && $_POST['payment_mode'] == 'Commission') ? 'selected' : ''; ?>>Commission Based</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="work_setup">Work Setup <span class="required">*</span></label>
                            <select id="work_setup" name="work_setup" required>
                                <option value="">Select work setup</option>
                                <option value="Remote" <?php echo (isset($_POST['work_setup']) && $_POST['work_setup'] == 'Remote') ? 'selected' : ''; ?>>Remote Work</option>
                                <option value="On-site" <?php echo (isset($_POST['work_setup']) && $_POST['work_setup'] == 'On-site') ? 'selected' : ''; ?>>On-site Work</option>
                                <option value="Hybrid" <?php echo (isset($_POST['work_setup']) && $_POST['work_setup'] == 'Hybrid') ? 'selected' : ''; ?>>Hybrid (Remote + On-site)</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="deadline">Project Deadline <span class="required">*</span></label>
                        <input type="date" id="deadline" name="deadline" value="<?php echo isset($_POST['deadline']) ? $_POST['deadline'] : ''; ?>" required>
                        <div class="help-text">Set a realistic deadline for project completion</div>
                    </div>
                </div>

                <div class="form-section">
                    <h3>Project Visual</h3>
                    <div class="file-upload-container" id="uploadContainer">
                        <div class="upload-text" id="uploadText">Click here to upload a project image or reference</div>
                        <input type="file" id="image" name="image" accept="image/*">
                        <div class="upload-hint">Accepted formats: JPEG, PNG, GIF • Max size: 5MB</div>
                    </div>
                    <div class="image-preview" id="imagePreview" style="display: none;">
                        <img id="previewImg" src="" alt="Preview">
                        <p style="margin-top: 10px; color: #28a745; font-weight: 500;">✅ Image selected successfully!</p>
                    </div>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">
                        Post Job
                    </button>
                    <a href="index.php" class="btn btn-secondary">
                        Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        // File upload handling
        document.getElementById('image').addEventListener('change', function(e) {
            const file = e.target.files[0];
            const uploadContainer = document.getElementById('uploadContainer');
            const uploadText = document.getElementById('uploadText');
            const imagePreview = document.getElementById('imagePreview');
            const previewImg = document.getElementById('previewImg');
            
            if (file) {
                // Validate file type
                const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
                if (!allowedTypes.includes(file.type)) {
                    alert('Please select a valid image file (JPEG, PNG, or GIF)');
                    this.value = '';
                    return;
                }
                
                // Validate file size (5MB)
                const maxSize = 5 * 1024 * 1024; // 5MB in bytes
                if (file.size > maxSize) {
                    alert('File size must be less than 5MB');
                    this.value = '';
                    return;
                }
                
                // Show preview
                const reader = new FileReader();
                reader.onload = function(e) {
                    previewImg.src = e.target.result;
                    imagePreview.style.display = 'block';
                };
                reader.readAsDataURL(file);
                
                // Update upload container styling
                uploadContainer.classList.add('file-selected');
                uploadText.textContent = 'File selected: ' + file.name;
                
            } else {
                // Reset if no file selected
                imagePreview.style.display = 'none';
                uploadContainer.classList.remove('file-selected');
                uploadText.textContent = 'Click here to upload a project image or reference';
            }
        });
        
        // Click anywhere in the upload container to trigger file selection
        document.getElementById('uploadContainer').addEventListener('click', function(e) {
            if (e.target !== document.getElementById('image')) {
                document.getElementById('image').click();
            }
        });
    </script>
</body>
</html>