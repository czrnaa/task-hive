<?php
session_start();
require 'database/config.php'; // DB connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email    = trim($_POST['email']);
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $_SESSION['error'] = "Both fields are required.";
        header("Location: login.php");
        exit;
    }

    $stmt = $conn->prepare("SELECT id, name, email, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 1) {
        $stmt->bind_result($id, $name, $db_email, $db_password);
        $stmt->fetch();

        if (password_verify($password, $db_password)) {
            $_SESSION['user_id'] = $id;
            $_SESSION['user_name'] = $name;
            $_SESSION['user_email'] = $db_email;

            header("Location: index.php");
            exit;
        } else {
            $_SESSION['error'] = "Incorrect password.";
        }
    } else {
        $_SESSION['error'] = "No account found with that email.";
    }

    header("Location: login.php");
    exit;
}
?>

<!-- HTML Design Part -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Task Hive</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

    <audio id="bgMusic" autoplay loop>
        <source src="assets/audio/background_music.mp3" type="audio/mpeg">
    </audio>
    <button id="musicToggle">Mute Music</button>

    <div class="container">
        <div class="form-container">
            <h2>Login</h2>

            <?php
            if (isset($_SESSION['error'])) {
                echo "<div class='error'>" . htmlspecialchars($_SESSION['error']) . "</div>";
                unset($_SESSION['error']);
            }
            ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label>Email:</label>
                    <input type="email" name="email" required>
                </div>
                <div class="form-group">
                    <label>Password:</label>
                    <input type="password" name="password" required>
                </div>
                <button type="submit">Login</button>
            </form>
            <p><a href="forgot_password.php">Forgot your password?</a></p>
            <p><a href="register.php">Don't have an account? Register here</a></p>
        </div>
    </div>

    <script>
        const bgMusic = document.getElementById('bgMusic');
        const musicToggle = document.getElementById('musicToggle');
        let isPlaying = true;

        musicToggle.textContent = 'Mute Music';

        musicToggle.addEventListener('click', () => {
            if (isPlaying) {
                bgMusic.pause();
                musicToggle.textContent = 'Play Music';
                isPlaying = false;
            } else {
                bgMusic.play().then(() => {
                    musicToggle.textContent = 'Mute Music';
                    isPlaying = true;
                }).catch(err => console.log(err));
            }
        });
    </script>
</body>
</html>