<?php
session_start();
require 'database/config.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';
require 'PHPMailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function sendResetEmail($email, $token) {
    $mail = new PHPMailer(true);

    try {
        // SMTP Configuration
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'appdevdev6@gmail.com';        // Your Gmail
        $mail->Password   = 'ghibdevszucpvpop';            // App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        // Sender and recipient
        $mail->setFrom('appdevdev6@gmail.com', 'Task Hive Team');
        $mail->addAddress($email);

        // Email content
        $mail->isHTML(true);
        $mail->Subject = 'Reset Your Password - Task Hive';
       $mail->Body = "
    <h2>Password Reset Request</h2>
    <p>We received a request to reset your password for your Task Hive account.</p>
    <p>Click the link below to set a new password:</p>
    <a href='http://localhost/task-hive-main/reset_password.php?token=$token'>Reset Password</a>
    <p>If you didn't request a password reset, you can safely ignore this email.</p>
";


        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log('Mailer Error: ' . $mail->ErrorInfo);
        return false;
    }
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 1) {
        $token = bin2hex(random_bytes(32));
        $stmt = $conn->prepare("UPDATE users SET token = ? WHERE email = ?");
        $stmt->bind_param("ss", $token, $email);
        $stmt->execute();

        sendResetEmail($email, $token);
        $_SESSION['success'] = "Password reset email sent.";
    } else {
        $_SESSION['error'] = "Email not found.";
    }

    header("Location: forgot_password.php");
    exit;
}
?>

<!-- HTML -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Forgot Password - Task Hive</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

    <audio id="bgMusic" autoplay loop>
        <source src="assets/audio/background_music.mp3" type="audio/mpeg">
    </audio>
    <button id="musicToggle">Mute Music</button>

    <div class="container">
        <div class="form-container">
            <h2>Forgot Password</h2>

            <?php
            if (isset($_SESSION['error'])) {
                echo "<div class='error'>" . htmlspecialchars($_SESSION['error']) . "</div>";
                unset($_SESSION['error']);
            }
            if (isset($_SESSION['success'])) {
                echo "<div class='success'>" . htmlspecialchars($_SESSION['success']) . "</div>";
                unset($_SESSION['success']);
            }
            ?>

            <form method="POST">
                <div class="form-group">
                    <label>Email:</label>
                    <input type="email" name="email" required>
                </div>
                <button type="submit">Send Reset Link</button>
            </form>
        </div>
    </div>

    <script>
        const bgMusic = document.getElementById('bgMusic');
        const musicToggle = document.getElementById('musicToggle');
        let isPlaying = true;

        musicToggle.textContent = 'Mute Music';

        musicToggle.addEventListener('click', () => {
            if (isPlaying) {
                bgMusic.pause();
                musicToggle.textContent = 'Play Music';
                isPlaying = false;
            } else {
                bgMusic.play().then(() => {
                    musicToggle.textContent = 'Mute Music';
                    isPlaying = true;
                }).catch(err => console.log(err));
            }
        });
    </script>

</body>
</html>